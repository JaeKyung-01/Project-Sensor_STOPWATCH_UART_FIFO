`timescale 1ns / 1ps

module project_sensor_stopwatch_uart_fifo (
    input        clk,
    input        reset,
    input        btn_L,
    input        btn_R,
    input        btn_U,
    input        btn_D,
    input  [5:0] sw,
    input        sr04_echo,
    inout        dht11_io,
    input        rx,
    output       tx,
    output       sr04_trigger,
    output [7:0] fnd_data,
    output [3:0] fnd_com,
    output [5:0] led
);

    wire w_btn_L, w_btn_R, w_btn_U, w_btn_D;

    btn_debounce U_DEB_L (
        .clk  (clk),
        .reset(reset),
        .i_btn(btn_L),
        .o_btn(w_btn_L)
    );

    btn_debounce U_DEB_R (
        .clk  (clk),
        .reset(reset),
        .i_btn(btn_R),
        .o_btn(w_btn_R)
    );

    btn_debounce U_DEB_U (
        .clk  (clk),
        .reset(reset),
        .i_btn(btn_U),
        .o_btn(w_btn_U)
    );

    btn_debounce U_DEB_D (
        .clk  (clk),
        .reset(reset),
        .i_btn(btn_D),
        .o_btn(w_btn_D)
    );

    wire [ 7:0] w_rx_rdata;
    wire        w_rx_empty;
    wire        w_rx_pop;

    wire [ 7:0] w_tx_wdata;
    wire        w_tx_push;
    wire        w_tx_full;

    wire [14:0] w_ascii;

    uart_fifo U_UART_FIFO (
        .clk     (clk),
        .reset   (reset),
        .rx      (rx),
        .tx      (tx),
        .rx_rdata(w_rx_rdata),
        .rx_empty(w_rx_empty),
        .rx_pop  (w_rx_pop),
        .tx_wdata(w_tx_wdata),
        .tx_push (w_tx_push),
        .tx_full (w_tx_full)
    );

    ascii_decoder U_ASCII_DECODER (
        .rdata  (w_rx_rdata),
        .empty  (w_rx_empty),
        .pop    (w_rx_pop),
        .o_ascii(w_ascii)
    );

    wire w_sw_run_stop;
    wire w_sw_clear;
    wire w_sw_mode;

    wire [1:0] w_wt_change_sec;
    wire [1:0] w_wt_change_min;
    wire [1:0] w_wt_change_hour;

    wire w_wt_blink_sec;
    wire w_wt_blink_min;
    wire w_wt_blink_hour;

    wire w_sr04_start;
    wire w_dht11_start;

    wire [1:0] w_dht11_disp_sel;

    wire w_stopwatch_split_save;
    wire w_stopwatch_split_clear;

    wire [1:0] w_active_src;
    wire w_disp_mode;
    wire w_ctrl_send_trig;

    main_control_unit U_MAIN_CONTROL_UNIT (
        .clk                    (clk),
        .reset                  (reset),
        .i_ascii                (w_ascii),
        .btn_L                  (w_btn_L),
        .btn_R                  (w_btn_R),
        .btn_U                  (w_btn_U),
        .btn_D                  (w_btn_D),
        .sw                     (sw),
        .o_sw_run_stop          (w_sw_run_stop),
        .o_sw_clear             (w_sw_clear),
        .o_sw_mode              (w_sw_mode),
        .o_wt_change_sec        (w_wt_change_sec),
        .o_wt_change_min        (w_wt_change_min),
        .o_wt_change_hour       (w_wt_change_hour),
        .o_wt_blink_sec         (w_wt_blink_sec),
        .o_wt_blink_min         (w_wt_blink_min),
        .o_wt_blink_hour        (w_wt_blink_hour),
        .o_sr04_start           (w_sr04_start),
        .o_dht11_start          (w_dht11_start),
        .o_dht11_disp_sel       (w_dht11_disp_sel),
        .o_stopwatch_split_save (w_stopwatch_split_save),
        .o_stopwatch_split_clear(w_stopwatch_split_clear),
        .o_active_src           (w_active_src),
        .o_disp_mode            (w_disp_mode),
        .o_send_trig            (w_ctrl_send_trig)
    );

    wire [6:0] w_sw_msec;
    wire [5:0] w_sw_sec;
    wire [5:0] w_sw_min;
    wire [4:0] w_sw_hour;

    stopwatch_datapath U_STOPWATCH_DP (
        .clk     (clk),
        .reset   (reset),
        .run_stop(w_sw_run_stop),
        .clear   (w_sw_clear),
        .mode    (w_sw_mode),
        .msec    (w_sw_msec),
        .sec     (w_sw_sec),
        .min     (w_sw_min),
        .hour    (w_sw_hour)
    );

    reg w_split_save_d;

    always @(posedge clk, posedge reset) begin
        if (reset) w_split_save_d <= 1'b0;
        else w_split_save_d <= w_stopwatch_split_save;
    end

    wire w_split_save_edge = w_stopwatch_split_save & ~w_split_save_d;

    reg [6:0] w_split_msec;
    reg [5:0] w_split_sec;
    reg [5:0] w_split_min;
    reg [4:0] w_split_hour;

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            w_split_msec <= 7'd0;
            w_split_sec  <= 6'd0;
            w_split_min  <= 6'd0;
            w_split_hour <= 5'd0;
        end else if (w_stopwatch_split_clear) begin
            w_split_msec <= 7'd0;
            w_split_sec  <= 6'd0;
            w_split_min  <= 6'd0;
            w_split_hour <= 5'd0;
        end else if (w_split_save_edge) begin
            w_split_msec <= w_sw_msec;
            w_split_sec  <= w_sw_sec;
            w_split_min  <= w_sw_min;
            w_split_hour <= w_sw_hour;
        end
    end

    wire [6:0] w_wt_msec;
    wire [5:0] w_wt_sec;
    wire [5:0] w_wt_min;
    wire [4:0] w_wt_hour;

    watch_datapath U_WATCH_DP (
        .clk        (clk),
        .reset      (reset),
        .change_sec (w_wt_change_sec),
        .change_min (w_wt_change_min),
        .change_hour(w_wt_change_hour),
        .msec       (w_wt_msec),
        .sec        (w_wt_sec),
        .min        (w_wt_min),
        .hour       (w_wt_hour)
    );

    wire [8:0] w_sr04_distance;
    wire       w_sr04_done;

    sr04_controller U_SR04_CTRL (
        .clk     (clk),
        .reset   (reset),
        .start   (w_sr04_start),
        .echo    (sr04_echo),
        .done    (w_sr04_done),
        .trigger (sr04_trigger),
        .distance(w_sr04_distance)
    );

    wire [15:0] w_dht11_humidity;
    wire [15:0] w_dht11_temperature;

    wire w_dht11_done;
    wire w_dht11_valid;

    dht11 U_DHT11 (
        .clk        (clk),
        .reset      (reset),
        .start      (w_dht11_start),
        .humidity   (w_dht11_humidity),
        .temperature(w_dht11_temperature),
        .done       (w_dht11_done),
        .valid      (w_dht11_valid),
        .dht11_io   (dht11_io)
    );

    wire [ 6:0] w_sr04_msec_val = w_sr04_distance / 100;

    wire [ 6:0] w_sr04_sec_val = w_sr04_distance % 100;

    wire [ 7:0] w_dht11_temp_val = w_dht11_temperature[15:8];

    wire [ 7:0] w_dht11_humid_val = w_dht11_humidity[15:8];

    wire [10:0] w_dht11_fahr_calc = (w_dht11_temp_val * 9) / 5 + 32;

    wire [ 7:0] w_dht11_fahr_val = w_dht11_fahr_calc[7:0];

    reg  [ 7:0] w_dht11_disp_val;

    always @(*) begin
        case (w_dht11_disp_sel)
            2'b00: w_dht11_disp_val = w_dht11_temp_val;

            2'b01: w_dht11_disp_val = w_dht11_humid_val;

            2'b10: w_dht11_disp_val = w_dht11_fahr_val;

            default: w_dht11_disp_val = w_dht11_temp_val;
        endcase
    end

    reg [6:0] w_fnd_msec;
    reg [7:0] w_fnd_sec;
    reg [7:0] w_fnd_min;
    reg [4:0] w_fnd_hour;

    always @(*) begin
        case (w_active_src)
            2'b00: begin
                w_fnd_msec = w_sr04_sec_val;
                w_fnd_sec  = w_sr04_msec_val;
                w_fnd_min  = 8'd0;
                w_fnd_hour = 5'd0;
            end

            2'b01: begin
                if (sw[4]) begin
                    w_fnd_msec = w_split_msec;
                    w_fnd_sec  = w_split_sec;
                    w_fnd_min  = w_split_min;
                    w_fnd_hour = w_split_hour;
                end else begin
                    w_fnd_msec = w_sw_msec;
                    w_fnd_sec  = w_sw_sec;
                    w_fnd_min  = w_sw_min;
                    w_fnd_hour = w_sw_hour;
                end
            end

            2'b10: begin
                w_fnd_msec = w_wt_msec;
                w_fnd_sec  = w_wt_sec;
                w_fnd_min  = w_wt_min;
                w_fnd_hour = w_wt_hour;
            end

            default: begin
                w_fnd_msec = 7'd0;
                w_fnd_sec  = w_dht11_disp_val;
                w_fnd_min  = 8'd0;
                w_fnd_hour = 5'd0;
            end
        endcase
    end

    wire w_disp_mode_final =
        (w_active_src == 2'b00 ||
         w_active_src == 2'b11)
        ? 1'b0
        : w_disp_mode;

    wire [3:0] w_fnd_com_raw;

    fnd_controller #(
        .SEC_WIDTH(8),
        .MIN_WIDTH(8)
    ) U_FND_CONTROLLER (
        .clk         (clk),
        .reset       (reset),
        .msec        (w_fnd_msec),
        .sec         (w_fnd_sec),
        .min         (w_fnd_min),
        .hour        (w_fnd_hour),
        .display_mode(w_disp_mode_final),
        .fnd_com     (w_fnd_com_raw),
        .fnd_data    (fnd_data)
    );

    reg [25:0] w_blink_cnt;

    always @(posedge clk, posedge reset) begin
        if (reset) w_blink_cnt <= 26'd0;
        else w_blink_cnt <= w_blink_cnt + 26'd1;
    end

    wire w_blink_off_phase = w_blink_cnt[25];

    wire w_need_blank_sec =
        (w_active_src == 2'b10) &&
        w_wt_blink_sec &&
        (w_disp_mode_final == 1'b0) &&
        w_blink_off_phase;

    wire w_need_blank_min =
        (w_active_src == 2'b10) &&
        w_wt_blink_min &&
        (w_disp_mode_final == 1'b1) &&
        w_blink_off_phase;

    wire w_need_blank_hour =
        (w_active_src == 2'b10) &&
        w_wt_blink_hour &&
        (w_disp_mode_final == 1'b1) &&
        w_blink_off_phase;

    wire [3:0] w_blink_mask =
        ({4{w_need_blank_sec}} & 4'b1100) |
        ({4{w_need_blank_min}} & 4'b0011) |
        ({4{w_need_blank_hour}} & 4'b1100);

    assign fnd_com = w_fnd_com_raw | w_blink_mask;

    wire w_send_trig =
        w_ctrl_send_trig |
        w_sr04_done |
        (w_dht11_done & w_dht11_valid);

    wire [6:0] w_send_msec = w_fnd_msec;

    wire [5:0] w_send_sec = w_fnd_sec[5:0];

    wire [5:0] w_send_min = w_fnd_min[5:0];

    wire [4:0] w_send_hour = w_fnd_hour;

    ascii_sender U_ASCII_SENDER (
        .clk          (clk),
        .reset        (reset),
        .src_sel      (w_active_src),
        .send_trig    (w_send_trig),
        .sr04_distance(w_sr04_distance),
        .time_msec    (w_send_msec),
        .time_sec     (w_send_sec),
        .time_min     (w_send_min),
        .time_hour    (w_send_hour),
        .dht11_temp   (w_dht11_temp_val),
        .dht11_humid  (w_dht11_humid_val),
        .dht11_fahr   (w_dht11_fahr_val),
        .tx_data      (w_tx_wdata),
        .push         (w_tx_push),
        .full         (w_tx_full),
        .busy         (),
        .send_done    ()
    );

    assign led = 6'b111111;

endmodule
