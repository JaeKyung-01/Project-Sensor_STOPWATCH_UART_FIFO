`timescale 1ns / 1ps

module dht11 (
    input         clk,
    input         reset,
    input         start,
    output [15:0] humidity,
    output [15:0] temperature,
    output        done,
    output        valid,
    inout         dht11_io
);

    dht11_controller U_DHT11_CONTROLLER (
        .clk        (clk),
        .reset      (reset),
        .start      (start),
        .humidity   (humidity),
        .temperature(temperature),
        .done       (done),
        .valid      (valid),
        .dht11_io   (dht11_io)
    );

endmodule
