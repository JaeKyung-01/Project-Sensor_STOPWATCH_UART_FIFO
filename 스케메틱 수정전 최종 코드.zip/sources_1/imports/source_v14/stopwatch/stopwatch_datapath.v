`timescale 1ns / 1ps

module stopwatch_datapath #(
    parameter MSEC_WIDTH = 7,
    SEC_WIDTH = 6,
    MIN_WIDTH = 6,
    HOUR_WIDTH = 5
) (
    input clk,
    input reset,
    input run_stop,
    input clear,
    input mode,
    output reg [MSEC_WIDTH -1:0] msec,
    output reg [SEC_WIDTH -1:0] sec,
    output reg [MIN_WIDTH -1:0] min,
    output reg [HOUR_WIDTH -1:0] hour
);

    wire w_tick_100hz, w_tick_sec, w_tick_min, w_tick_hour;

    wire [MSEC_WIDTH -1:0] w_msec;
    wire [ SEC_WIDTH -1:0] w_sec;
    wire [ MIN_WIDTH -1:0] w_min;
    wire [HOUR_WIDTH -1:0] w_hour;

    tick_gen_100hz U_TICK_GEN (
        .clk   (clk),
        .reset (reset),
        .o_tick(w_tick_100hz)
    );

    stopwatch_time_counter #(
        .BIT_WIDTH(MSEC_WIDTH),
        .TIMES(100)
    ) MSEC_COUNTER (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_100hz),
        .mode      (mode),
        .run_stop  (run_stop),
        .clear     (clear),
        .time_count(w_msec),
        .o_tick    (w_tick_sec)
    );

    stopwatch_time_counter #(
        .BIT_WIDTH(SEC_WIDTH),
        .TIMES(60)
    ) SEC_COUNTER (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_sec),
        .mode      (mode),
        .run_stop  (run_stop),
        .clear     (clear),
        .time_count(w_sec),
        .o_tick    (w_tick_min)
    );

    stopwatch_time_counter #(
        .BIT_WIDTH(MIN_WIDTH),
        .TIMES(60)
    ) MIN_COUNTER (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_min),
        .mode      (mode),
        .run_stop  (run_stop),
        .clear     (clear),
        .time_count(w_min),
        .o_tick    (w_tick_hour)
    );

    stopwatch_time_counter #(
        .BIT_WIDTH(HOUR_WIDTH),
        .TIMES(24)
    ) HOUR_COUNTER (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_hour),
        .mode      (mode),
        .run_stop  (run_stop),
        .clear     (clear),
        .time_count(w_hour),
        .o_tick    ()
    );

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            msec <= 0;
            sec  <= 0;
            min  <= 0;
            hour <= 0;
        end else begin
            msec <= w_msec;
            sec  <= w_sec;
            min  <= w_min;
            hour <= w_hour;
        end
    end

endmodule
