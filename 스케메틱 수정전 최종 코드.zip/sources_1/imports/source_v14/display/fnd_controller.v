`timescale 1ns / 1ps

module fnd_controller #(parameter MSEC_WIDTH = 7, 
    SEC_WIDTH = 6, 
    MIN_WIDTH = 6, 
    HOUR_WIDTH = 5
    ) (
    input clk,
    input reset,
    input [MSEC_WIDTH-1:0] msec,
    input [SEC_WIDTH-1:0] sec,
    input [MIN_WIDTH-1:0] min,
    input [HOUR_WIDTH-1:0] hour,
    input display_mode,
    output [3:0] fnd_com,
    output [7:0] fnd_data
);
    
   
    wire [3:0] bcd;
    wire [2:0] w_digit_sel;
    wire w_1khz;
    wire [3:0] w_msec_digit_1, w_msec_digit_10, w_sec_digit_1, w_sec_digit_10, w_min_digit_1, w_min_digit_10, w_hour_digit_1, w_hour_digit_10;
    wire [3:0] w_msec_sec, w_min_hour;
    wire w_dot_onoff;

    bcd U_BCD(
        .bcd_in(bcd),
        .bcd_out(fnd_data)    
    );

    clk_div U_CLK_DIV(
    .clk(clk),
    .reset(reset),
    .o_1khz(w_1khz)
);
 digit_spliter  #(
    .BIT_WIDTH(MSEC_WIDTH))
    DIGIT_SPLITTER_MSEC(
    .ds_in(msec),
    .digit_1(w_msec_digit_1),
    .digit_10(w_msec_digit_10)

);
digit_spliter  #( 
    .BIT_WIDTH(SEC_WIDTH))
    DIGIT_SPLITTER_SEC(
    .ds_in(sec),
    .digit_1(w_sec_digit_1),
    .digit_10(w_sec_digit_10)

);
digit_spliter 
 #( .BIT_WIDTH(MIN_WIDTH))
 DIGIT_SPLITTER_MIN(
    .ds_in(min),
    .digit_1(w_min_digit_1),
    .digit_10(w_min_digit_10)

);
digit_spliter 
 #( .BIT_WIDTH(HOUR_WIDTH))
 DIGIT_SPLITTER_HOUR(
    .ds_in(hour),
    .digit_1(w_hour_digit_1),
    .digit_10(w_hour_digit_10)

);
comparator_dot 
#(.MSEC_WIDTH(7)) U_COMPARATOR_DOT(
    .msec(msec),
    .dot_onoff(w_dot_onoff)
);
    counter_8 U_COUNTER_8(
        .clk(w_1khz),
        .reset(reset),
        .digit_sel(w_digit_sel)
    );
    decoder_2x4 UDECODER_2x4(
    .digit_sel(w_digit_sel[1:0]),
    .fnd_com(fnd_com)
    );
    

  mux_8x1 U_MUX_8x1_MSEC_SEC(
    .sel(w_digit_sel),
    .in0(w_msec_digit_1),
    .in1(w_msec_digit_10),
    .in2(w_sec_digit_1),
    .in3(w_sec_digit_10),
    .in4(4'b1111),
    .in5(4'b1111),
    .in6({3'b111, w_dot_onoff}),
    .in7(4'b1111),
    .mux_out(w_msec_sec)
);
mux_8x1 U_MUX_8x1_MIN_HOUR(
    .sel(w_digit_sel),
    .in0(w_min_digit_1),
    .in1(w_min_digit_10),
    .in2(w_hour_digit_1),
    .in3(w_hour_digit_10),
    .in4(4'b1111),
    .in5(4'b1111),
    .in6({3'b111, w_dot_onoff}),
    .in7(4'b1111),
    .mux_out(w_min_hour)
);

fnd_mux_2x1 U_MUX_2x1(
    .sel(display_mode),
    .in0(w_msec_sec),
    .in1(w_min_hour),
    .mux_out(bcd)
);

endmodule
