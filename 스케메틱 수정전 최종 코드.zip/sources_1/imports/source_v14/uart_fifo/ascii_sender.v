`timescale 1ns / 1ps

module ascii_sender (
    input clk,
    input reset,

    input [1:0] src_sel,
    input send_trig,

    input [8:0] sr04_distance,

    input [6:0] time_msec,
    input [5:0] time_sec,
    input [5:0] time_min,
    input [4:0] time_hour,

    input [7:0] dht11_temp,
    input [7:0] dht11_humid,
    input [7:0] dht11_fahr,

    output reg [7:0] tx_data,
    output reg push,
    input full,

    output reg busy,
    output reg send_done
);

    localparam IDLE = 2'd0, SEND = 2'd1, DONE_ST = 2'd2;

    reg [1:0] state, next_state;

    localparam BUF_LEN = 20;

    reg [7:0] buf_mem[0:BUF_LEN-1];
    reg [4:0] len_reg;
    reg [4:0] idx_reg;

    wire [3:0] d_dist_1 = sr04_distance % 10;
    wire [3:0] d_dist_10 = (sr04_distance / 10) % 10;
    wire [3:0] d_dist_100 = (sr04_distance / 100) % 10;

    wire [3:0] d_msec_1 = time_msec % 10;
    wire [3:0] d_msec_10 = (time_msec / 10) % 10;
    wire [3:0] d_sec_1 = time_sec % 10;
    wire [3:0] d_sec_10 = (time_sec / 10) % 10;
    wire [3:0] d_min_1 = time_min % 10;
    wire [3:0] d_min_10 = (time_min / 10) % 10;
    wire [3:0] d_hour_1 = time_hour % 10;
    wire [3:0] d_hour_10 = (time_hour / 10) % 10;

    wire [3:0] d_temp_1 = dht11_temp % 10;
    wire [3:0] d_temp_10 = (dht11_temp / 10) % 10;
    wire [3:0] d_humid_1 = dht11_humid % 10;
    wire [3:0] d_humid_10 = (dht11_humid / 10) % 10;

    wire [3:0] d_fahr_1 = dht11_fahr % 10;
    wire [3:0] d_fahr_10 = (dht11_fahr / 10) % 10;
    wire [3:0] d_fahr_100 = (dht11_fahr / 100) % 10;

    function [7:0] to_ascii;
        input [3:0] bcd;
        begin
            to_ascii = {4'h3, bcd};
        end
    endfunction

    always @(posedge clk, posedge reset) begin
        if (reset) state <= IDLE;
        else state <= next_state;
    end

    always @(*) begin
        next_state = state;

        case (state)
            IDLE: if (send_trig) next_state = SEND;
            SEND: if (!full && idx_reg == len_reg - 1) next_state = DONE_ST;
            DONE_ST: next_state = IDLE;
            default: next_state = IDLE;
        endcase
    end

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            len_reg <= 5'd0;
        end else if (state == IDLE && send_trig) begin
            case (src_sel)
                2'b00: begin
                    buf_mem[0] <= "D";
                    buf_mem[1] <= ":";
                    buf_mem[2] <= to_ascii(d_dist_100);
                    buf_mem[3] <= to_ascii(d_dist_10);
                    buf_mem[4] <= to_ascii(d_dist_1);
                    buf_mem[5] <= "c";
                    buf_mem[6] <= "m";
                    buf_mem[7] <= 8'h0D;
                    buf_mem[8] <= 8'h0A;
                    len_reg <= 5'd9;
                end

                2'b01: begin
                    buf_mem[0] <= "S";
                    buf_mem[1] <= "T";
                    buf_mem[2] <= " ";
                    buf_mem[3] <= to_ascii(d_min_10);
                    buf_mem[4] <= to_ascii(d_min_1);
                    buf_mem[5] <= ":";
                    buf_mem[6] <= to_ascii(d_sec_10);
                    buf_mem[7] <= to_ascii(d_sec_1);
                    buf_mem[8] <= ".";
                    buf_mem[9] <= to_ascii(d_msec_10);
                    buf_mem[10] <= to_ascii(d_msec_1);
                    buf_mem[11] <= 8'h0D;
                    buf_mem[12] <= 8'h0A;
                    len_reg <= 5'd13;
                end

                2'b10: begin
                    buf_mem[0] <= "W";
                    buf_mem[1] <= "T";
                    buf_mem[2] <= " ";
                    buf_mem[3] <= to_ascii(d_hour_10);
                    buf_mem[4] <= to_ascii(d_hour_1);
                    buf_mem[5] <= ":";
                    buf_mem[6] <= to_ascii(d_min_10);
                    buf_mem[7] <= to_ascii(d_min_1);
                    buf_mem[8] <= ":";
                    buf_mem[9] <= to_ascii(d_sec_10);
                    buf_mem[10] <= to_ascii(d_sec_1);
                    buf_mem[11] <= 8'h0D;
                    buf_mem[12] <= 8'h0A;
                    len_reg <= 5'd13;
                end

                default: begin
                    buf_mem[0] <= "D";
                    buf_mem[1] <= "H";
                    buf_mem[2] <= ":";
                    buf_mem[3] <= to_ascii(d_temp_10);
                    buf_mem[4] <= to_ascii(d_temp_1);
                    buf_mem[5] <= "C";
                    buf_mem[6] <= ",";
                    buf_mem[7] <= to_ascii(d_humid_10);
                    buf_mem[8] <= to_ascii(d_humid_1);
                    buf_mem[9] <= "%";
                    buf_mem[10] <= ",";
                    buf_mem[11] <= to_ascii(d_fahr_100);
                    buf_mem[12] <= to_ascii(d_fahr_10);
                    buf_mem[13] <= to_ascii(d_fahr_1);
                    buf_mem[14] <= "F";
                    buf_mem[15] <= 8'h0D;
                    buf_mem[16] <= 8'h0A;
                    len_reg <= 5'd17;
                end
            endcase
        end
    end

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            idx_reg <= 5'd0;
            tx_data <= 8'd0;
            push <= 1'b0;
            busy <= 1'b0;
            send_done <= 1'b0;
        end else begin
            push <= 1'b0;
            send_done <= 1'b0;

            case (state)
                IDLE: begin
                    busy <= 1'b0;
                    if (send_trig) begin
                        idx_reg <= 5'd0;
                        busy <= 1'b1;
                    end
                end

                SEND: begin
                    if (!full) begin
                        tx_data <= buf_mem[idx_reg];
                        push <= 1'b1;
                        if (idx_reg != len_reg - 1) idx_reg <= idx_reg + 5'd1;
                    end
                end

                DONE_ST: begin
                    busy <= 1'b0;
                    send_done <= 1'b1;
                end

                default: ;
            endcase
        end
    end

endmodule