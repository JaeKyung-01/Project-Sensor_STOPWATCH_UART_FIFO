`timescale 1ns / 1ps

// =========================================================
// top_dht11
//  - valid==1 (checksum OK) 일 때만 humidity/temperature 값을
//    래치하여 FND에 표시. checksum 틀리면 이전 정상값 유지.
// =========================================================
module top_dht11 (
    input         clk,
    input         reset,
    input         btnR,
    input         sw_sel,
    inout         dht11_io,
    output [3:0]  fnd_com,
    output [7:0]  fnd_data
);

    wire        w_btn_start;
    wire [15:0] w_humidity;
    wire [15:0] w_temperature;
    wire        w_done;
    wire        w_valid;
    wire [7:0]  w_selected_data;
    wire [13:0] w_fnd_in;

    // ---- 정상 수신된(valid) 값만 래치 ----
    reg [15:0] humidity_latched;
    reg [15:0] temperature_latched;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            humidity_latched    <= 16'd0;
            temperature_latched <= 16'd0;
        end
        else if (w_done && w_valid) begin
            humidity_latched    <= w_humidity;
            temperature_latched <= w_temperature;
        end
        // done && !valid 인 경우는 아무 것도 안 함 -> 이전 값 유지
    end

    btn_debounce U_BD_START (
        .clk   (clk),
        .reset (reset),
        .i_btn (btnR),
        .o_btn (w_btn_start)
    );

    dht11 U_DHT11 (
        .clk         (clk),
        .reset       (reset),
        .start       (w_btn_start),
        .humidity    (w_humidity),
        .temperature (w_temperature),
        .done        (w_done),
        .valid       (w_valid),
        .dht11_io    (dht11_io)
    );

    assign w_selected_data =
        sw_sel ? temperature_latched[15:8] : humidity_latched[15:8];

    assign w_fnd_in = {6'b000000, w_selected_data};

    fnd_controller U_FND_CNTL (
        .clk      (clk),
        .reset    (reset),
        .fnd_in   (w_fnd_in),
        .fnd_com  (fnd_com),
        .fnd_data (fnd_data)
    );

endmodule


module dht11 (
    input         clk,
    input         reset,
    input         start,
    output [15:0] humidity,
    output [15:0] temperature,
    output        done,
    output        valid,
    inout         dht11_io
);

    dht11_controller U_DHT11_CONTROLLER (
        .clk         (clk),
        .reset       (reset),
        .start       (start),
        .humidity    (humidity),
        .temperature (temperature),
        .done        (done),
        .valid       (valid),
        .dht11_io    (dht11_io)
    );

endmodule


// =========================================================
// dht11_controller
//  - SYNC: LOW(80us) 뿐 아니라 HIGH(80us)까지 다 소비한 뒤에
//          DATA 상태로 진입하도록 3단계로 세분화 (버그 수정)
//  - WAIT: 실제로 dht11_in이 Low로 떨어지는지 확인 후 SYNC 진입
//          (버그 수정, 타임아웃 안전장치 포함)
//  - DATA phase1(HIGH 측정)에 타임아웃 안전장치 추가
// =========================================================
module dht11_controller (
    input         clk,
    input         reset,
    input         start,
    output [15:0] humidity,
    output [15:0] temperature,
    output reg    done,
    output reg    valid,
    inout         dht11_io
);

    localparam [2:0]
        IDLE  = 3'd0,
        START = 3'd1,
        WAIT  = 3'd2,
        SYNC  = 3'd3,
        DATA  = 3'd4,
        STOP  = 3'd5;

    // SYNC 내부 3단계
    localparam [1:0]
        SYNC_WAIT_LOW  = 2'd0,  // 최초 low(응답 시작) 감지 대기
        SYNC_MEAS_LOW  = 2'd1,  // 80us LOW 구간 측정
        SYNC_MEAS_HIGH = 2'd2;  // 80us HIGH 구간 측정 (신규 추가)

    reg [2:0] c_state;
    reg [2:0] n_state;

    reg [14:0] tick_count_reg;
    reg [14:0] tick_count_next;

    reg [5:0] bit_count_reg;
    reg [5:0] bit_count_next;

    reg [39:0] data_reg;
    reg [39:0] data_next;

    reg io_control;
    reg dht11_io_reg;
    reg dht11_io_next;

    reg [1:0] sync_phase_reg;
    reg [1:0] sync_phase_next;

    // WAIT 내부 단계: START에서 우리가 누르던 LOW 잔상과
    // 진짜 DHT11 응답(LOW)을 구분하기 위해 2단계로 분리
    reg wait_released_reg;
    reg wait_released_next;

    reg data_phase_reg;
    reg data_phase_next;

    wire [7:0] checksum;
    wire [7:0] calc_checksum;

    reg dht_sync1;
    reg dht_sync2;

    wire dht11_in;
    wire tick_us;

    // 타임아웃 기준값 (100us 이상 응답 없으면 IDLE로 복귀)
    localparam [14:0] TIMEOUT_US = 15'd100;

    assign dht11_io =
        io_control ? dht11_io_reg : 1'bz;

    assign dht11_in = dht_sync2;

    assign humidity = data_reg[39:24];

    assign temperature = data_reg[23:8];

    assign checksum = data_reg[7:0];

    assign calc_checksum =
        humidity[15:8] +
        humidity[7:0] +
        temperature[15:8] +
        temperature[7:0];

    dht_11_tick_us U_TICK_US (
        .clk       (clk),
        .reset     (reset),
        .run_stop  (1'b1),
        .clear     (1'b0),
        .o_tick_us (tick_us)
    );

    // dht11_io 입력 동기화 (metastability 방지, 2FF synchronizer)
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            dht_sync1 <= 1'b1;
            dht_sync2 <= 1'b1;
        end
        else begin
            dht_sync1 <= dht11_io;
            dht_sync2 <= dht_sync1;
        end
    end

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            c_state        <= IDLE;
            tick_count_reg <= 15'd0;
            bit_count_reg  <= 6'd0;
            data_reg       <= 40'd0;
            dht11_io_reg   <= 1'b1;
            sync_phase_reg <= SYNC_WAIT_LOW;
            data_phase_reg <= 1'b0;
            wait_released_reg <= 1'b0;
        end
        else begin
            c_state        <= n_state;
            tick_count_reg <= tick_count_next;
            bit_count_reg  <= bit_count_next;
            data_reg       <= data_next;
            dht11_io_reg   <= dht11_io_next;
            wait_released_reg <= wait_released_next;
            sync_phase_reg <= sync_phase_next;
            data_phase_reg <= data_phase_next;
        end
    end

    always @(*) begin
        n_state = c_state;

        tick_count_next = tick_count_reg;
        bit_count_next  = bit_count_reg;
        data_next       = data_reg;

        dht11_io_next = dht11_io_reg;

        sync_phase_next = sync_phase_reg;
        data_phase_next = data_phase_reg;
        wait_released_next = wait_released_reg;

        io_control = 1'b0;

        done  = 1'b0;
        valid = 1'b0;

        case (c_state)

            IDLE: begin
                io_control = 1'b0;

                tick_count_next = 15'd0;
                bit_count_next  = 6'd0;

                sync_phase_next = SYNC_WAIT_LOW;
                data_phase_next = 1'b0;
                wait_released_next = 1'b0;

                if (start) begin
                    n_state = START;
                    tick_count_next = 15'd0;
                end
            end

            START: begin
                // MCU가 최소 18ms LOW 유지 -> 19ms(=18999us+1)로 여유
                io_control = 1'b1;
                dht11_io_next = 1'b0;

                if (tick_us) begin
                    if (tick_count_reg == 15'd18999) begin
                        tick_count_next = 15'd0;
                        wait_released_next = 1'b0;
                        n_state = WAIT;
                    end
                    else begin
                        tick_count_next = tick_count_reg + 1'b1;
                    end
                end
            end

            WAIT: begin
                // [버그 수정] START에서 우리가 눌러놨던 LOW의 잔상(동기화
                // 파이프라인 지연)을 센서 응답으로 오인하지 않도록,
                // 먼저 라인이 진짜 High로 올라간 걸 확인(wait_released)한
                // 뒤에야 Low(=DHT11 응답 시작)를 감지하도록 2단계로 처리
                io_control = 1'b0;

                if (!wait_released_reg) begin
                    // 1단계: 라인이 실제로 High로 올라갈 때까지 대기
                    if (dht11_in) begin
                        wait_released_next = 1'b1;
                        tick_count_next = 15'd0;
                    end
                    else if (tick_us) begin
                        if (tick_count_reg >= TIMEOUT_US) begin
                            tick_count_next = 15'd0;
                            n_state = IDLE;
                        end
                        else begin
                            tick_count_next = tick_count_reg + 1'b1;
                        end
                    end
                end
                else begin
                    // 2단계: High 확인 이후 Low로 떨어지면 진짜 센서 응답
                    if (!dht11_in) begin
                        tick_count_next = 15'd0;
                        sync_phase_next = SYNC_WAIT_LOW;
                        n_state = SYNC;
                    end
                    else if (tick_us) begin
                        if (tick_count_reg >= TIMEOUT_US) begin
                            // 타임아웃: 센서 응답 없음 -> IDLE로 복귀
                            tick_count_next = 15'd0;
                            n_state = IDLE;
                        end
                        else begin
                            tick_count_next = tick_count_reg + 1'b1;
                        end
                    end
                end
            end

            SYNC: begin
                // [버그 수정] LOW(80us) + HIGH(80us) 둘 다 소비한 뒤
                // 실제 데이터 비트 시작(다시 Low로 떨어지는 시점)에 DATA로 진입
                io_control = 1'b0;

                case (sync_phase_reg)

                    SYNC_WAIT_LOW: begin
                        // WAIT에서 이미 low 감지하고 넘어왔으므로 바로 측정 시작
                        tick_count_next = 15'd0;
                        sync_phase_next = SYNC_MEAS_LOW;
                    end

                    SYNC_MEAS_LOW: begin
                        if (dht11_in) begin
                            // low -> high 전이 감지: 80us LOW 구간 종료
                            tick_count_next = 15'd0;
                            sync_phase_next = SYNC_MEAS_HIGH;
                        end
                        else if (tick_us) begin
                            if (tick_count_reg >= TIMEOUT_US) begin
                                tick_count_next = 15'd0;
                                n_state = IDLE;
                            end
                            else begin
                                tick_count_next = tick_count_reg + 1'b1;
                            end
                        end
                    end

                    SYNC_MEAS_HIGH: begin
                        if (!dht11_in) begin
                            // high -> low 전이 감지: 80us HIGH 구간 종료
                            // 이 시점이 바로 "첫 데이터 비트의 50us LOW" 시작점
                            tick_count_next = 15'd0;
                            bit_count_next  = 6'd0;
                            data_phase_next = 1'b0;
                            n_state = DATA;
                        end
                        else if (tick_us) begin
                            if (tick_count_reg >= TIMEOUT_US) begin
                                tick_count_next = 15'd0;
                                n_state = IDLE;
                            end
                            else begin
                                tick_count_next = tick_count_reg + 1'b1;
                            end
                        end
                    end

                    default: begin
                        sync_phase_next = SYNC_WAIT_LOW;
                    end

                endcase
            end

            DATA: begin
                // 매 비트: 50us LOW로 시작 -> 이후 HIGH 길이로 0/1 판별
                // (26~28us=0, 70us=1 이므로 threshold 50us 기준 판별)
                io_control = 1'b0;

                if (!data_phase_reg) begin
                    // phase0: 현재 LOW 구간 -> HIGH로 바뀌는 순간 phase1로
                    if (dht11_in) begin
                        tick_count_next = 15'd0;
                        data_phase_next = 1'b1;
                    end
                    else if (tick_us) begin
                        if (tick_count_reg >= TIMEOUT_US) begin
                            tick_count_next = 15'd0;
                            n_state = IDLE;
                        end
                        else begin
                            tick_count_next = tick_count_reg + 1'b1;
                        end
                    end
                end
                else begin
                    // phase1: HIGH 구간 길이 측정
                    if (dht11_in) begin
                        if (tick_us) begin
                            if (tick_count_reg >= TIMEOUT_US) begin
                                // [추가] HIGH가 비정상적으로 계속되면 타임아웃
                                tick_count_next = 15'd0;
                                n_state = IDLE;
                            end
                            else begin
                                tick_count_next = tick_count_reg + 1'b1;
                            end
                        end
                    end
                    else begin
                        // HIGH -> LOW 전이: 비트 확정
                        if (tick_count_reg >= 15'd50) begin
                            data_next = {data_reg[38:0], 1'b1};
                        end
                        else begin
                            data_next = {data_reg[38:0], 1'b0};
                        end

                        tick_count_next = 15'd0;
                        data_phase_next = 1'b0;

                        if (bit_count_reg == 6'd39) begin
                            n_state = STOP;
                        end
                        else begin
                            bit_count_next = bit_count_reg + 1'b1;
                        end
                    end
                end
            end

            STOP: begin
                io_control = 1'b0;

                done = 1'b1;

                if (checksum == calc_checksum)
                    valid = 1'b1;
                else
                    valid = 1'b0;

                n_state = IDLE;
                tick_count_next = 15'd0;
            end

            default: begin
                n_state = IDLE;
                tick_count_next = 15'd0;
                bit_count_next  = 6'd0;
                data_next       = 40'd0;
                sync_phase_next = SYNC_WAIT_LOW;
                data_phase_next = 1'b0;
                wait_released_next = 1'b0;
            end

        endcase
    end

endmodule


module dht_11_tick_us (
    input clk,
    input reset,
    input run_stop,
    input clear,
    output o_tick_us
);

    parameter F_COUNT = 100;

    reg [$clog2(F_COUNT)-1:0] counter_reg;
    reg tick_us_reg;

    assign o_tick_us = tick_us_reg;

    always @(posedge clk or posedge reset) begin
        if (reset || clear) begin
            counter_reg <= 0;
            tick_us_reg <= 1'b0;
        end
        else if (run_stop) begin
            if (counter_reg == F_COUNT - 1) begin
                counter_reg <= 0;
                tick_us_reg <= 1'b1;
            end
            else begin
                counter_reg <= counter_reg + 1'b1;
                tick_us_reg <= 1'b0;
            end
        end
        else begin
            tick_us_reg <= 1'b0;
        end
    end

endmodule
