`timescale 1ns / 1ps

module uart_stopwatch_watch (
    input        clk,
    input        reset,
    input  [2:0] sw,
    input        sw_watch,
    input        sw_stop,
    input        btn_L,
    input        btn_R,
    input        btn_U,
    input        btn_D,
    input        rx,
    output       tx,
    output [3:0] fnd_com,
    output [7:0] fnd_data,
    output [3:0] led
);

    wire w_watch_btn_L, w_watch_btn_R, w_watch_btn_U, w_watch_btn_D;
    wire w_stop_btn_L, w_stop_btn_R, w_stop_btn_U, w_stop_btn_D;
    wire [3:0] watch_fnd_com, stop_fnd_com;
    wire [7:0] watch_fnd_data, stop_fnd_data;
    wire [2:0] watch_led, stop_led;

    uart_command_controller U_UART_COMMAND_CTRL (
        .clk            (clk),
        .reset          (reset),
        .sw_watch       (sw_watch),
        .sw_stop        (sw_stop),
        .btn_L          (btn_L),
        .btn_R          (btn_R),
        .btn_U          (btn_U),
        .btn_D          (btn_D),
        .rx             (rx),
        .tx             (tx),
        .watch_btn_L_out(w_watch_btn_L),
        .watch_btn_R_out(w_watch_btn_R),
        .watch_btn_U_out(w_watch_btn_U),
        .watch_btn_D_out(w_watch_btn_D),
        .stop_btn_L_out (w_stop_btn_L),
        .stop_btn_R_out (w_stop_btn_R),
        .stop_btn_U_out (w_stop_btn_U),
        .stop_btn_D_out (w_stop_btn_D)
    );

    fnd_display_mux U_FND_MUX (
        .sw_watch      (sw_watch),
        .sw_stop       (sw_stop),
        .watch_fnd_com (watch_fnd_com),
        .watch_fnd_data(watch_fnd_data),
        .stop_fnd_com  (stop_fnd_com),
        .stop_fnd_data (stop_fnd_data),
        .fnd_com       (fnd_com),
        .fnd_data      (fnd_data),
        .led           (led)
    );

    top_stopwatch U_STOPWATCH (
        .clk     (clk),
        .reset   (reset),
        .sw      (sw[2:0]),
        .sw_stop (sw_stop),
        .btn_L   (w_stop_btn_L),
        .btn_R   (w_stop_btn_R),
        .btn_U   (w_stop_btn_U),
        .btn_D   (w_stop_btn_D),
        .fnd_com (stop_fnd_com),
        .fnd_data(stop_fnd_data)
    );

    top_watch U_WATCH (
        .clk     (clk),
        .reset   (reset),
        .sw      (sw[1:0]),
        .sw_watch(sw_watch),
        .btn_L   (w_watch_btn_L),
        .btn_R   (w_watch_btn_R),
        .btn_U   (w_watch_btn_U),
        .btn_D   (w_watch_btn_D),
        .fnd_com (watch_fnd_com),
        .fnd_data(watch_fnd_data)
    );

endmodule
