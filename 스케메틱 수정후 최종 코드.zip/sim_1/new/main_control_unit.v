`timescale 1ns / 1ps

module tb_main_control_unit_s4();

    // Inputs
    reg clk;
    reg reset;
    reg [14:0] i_ascii;
    reg btn_L;
    reg btn_R;
    reg btn_U;
    reg btn_D;
    reg [7:0] sw;

    // Outputs
    wire o_sw_run_stop;
    wire o_sw_clear;
    wire o_sw_mode;
    wire [1:0] o_wt_change_sec;
    wire [1:0] o_wt_change_min;
    wire [1:0] o_wt_change_hour;
    wire o_wt_blink_sec;
    wire o_wt_blink_min;
    wire o_wt_blink_hour;
    wire o_sr04_start;
    wire o_dht11_start;
    wire [1:0] o_dht11_disp_sel;
    wire o_stopwatch_split_save;
    wire o_stopwatch_split_clear;
    wire [1:0] o_active_src;
    wire o_disp_mode;
    wire o_send_trig;

    // Instantiate the Unit Under Test (UUT)
    main_control_unit uut (
        .clk(clk),
        .reset(reset),
        .i_ascii(i_ascii),
        .btn_L(btn_L),
        .btn_R(btn_R),
        .btn_U(btn_U),
        .btn_D(btn_D),
        .sw(sw),
        .o_sw_run_stop(o_sw_run_stop),
        .o_sw_clear(o_sw_clear),
        .o_sw_mode(o_sw_mode),
        .o_wt_change_sec(o_wt_change_sec),
        .o_wt_change_min(o_wt_change_min),
        .o_wt_change_hour(o_wt_change_hour),
        .o_wt_blink_sec(o_wt_blink_sec),
        .o_wt_blink_min(o_wt_blink_min),
        .o_wt_blink_hour(o_wt_blink_hour),
        .o_sr04_start(o_sr04_start),
        .o_dht11_start(o_dht11_start),
        .o_dht11_disp_sel(o_dht11_disp_sel),
        .o_stopwatch_split_save(o_stopwatch_split_save),
        .o_stopwatch_split_clear(o_stopwatch_split_clear),
        .o_active_src(o_active_src),
        .o_disp_mode(o_disp_mode),
        .o_send_trig(o_send_trig)
    );

    // 100MHz 클럭 생성 (주기 10ns)
    always #5 clk = ~clk;

    initial begin
        // 초기화
        clk = 0;
        reset = 1;
        i_ascii = 15'd0;
        btn_L = 0;
        btn_R = 0;
        btn_U = 0;
        btn_D = 0;
        sw = 8'd0;

        // 리셋 해제
        #50;
        reset = 0;
        #30;

        // ==================================================
        // [시나리오 4] Watch 모드 시간 설정 및 블링킹 제어 검증
        // ==================================================

        // 1. Watch 모드 진입 (sw[0] = 1 -> sw = 1)
        sw = 8'b0000_0001; 
        #50;
        
        // 2. 수정/설정 모드 진입 및 블링크 위치 순환 (예: btn_R 입력 활용)
        btn_R = 1; #40; btn_R = 0; #40; // 첫 번째 블링크 전환 (초 등)
        btn_R = 1; #40; btn_R = 0; #40; // 두 번째 블링크 전환 (분 등)
        btn_R = 1; #40; btn_R = 0; #40; // 세 번째 블링크 전환 (시 등)

        // 3. 수정 모드 내에서 값 증가/감소 버튼 입력 테스트 (btn_U, btn_D)
        btn_U = 1; #40; btn_U = 0; #40; // 시간 값 증가
        btn_D = 1; #40; btn_D = 0; #40; // 시간 값 감소

        // 4. 다른 모드로 전환 시 블링킹 및 설정 상태 해제 확인 (예: Stopwatch 모드로 전환)
        sw = 8'b0000_0010; 
        #50;

        // 시뮬레이션 종료
        #100;
        $finish;
    end

endmodule