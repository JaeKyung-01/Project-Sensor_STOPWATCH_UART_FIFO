`timescale 1ns / 1ps

module watch_datapath (
    input        clk,
    input        reset,
    input  [1:0] change_sec,
    input  [1:0] change_min,
    input  [1:0] change_hour,
    output [6:0] msec,
    output [5:0] sec,
    output [5:0] min,
    output [4:0] hour
);

    wire w_tick_100hz, w_tick_sec, w_tick_min, w_tick_hour;

    tick_gen_100hz U_TICK_GEN (
        .clk   (clk),
        .reset (reset),
        .o_tick(w_tick_100hz)
    );

    watch_time_counter #(
        .BIT_WIDTH(5),
        .TIMES(24),
        .TIME(12)
    ) U_HOUR_CNTL (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_hour),
        .set_time  (change_hour),
        .time_count(hour),
        .o_tick    ()
    );

    watch_time_counter #(
        .BIT_WIDTH(6),
        .TIMES(60),
        .TIME(0)
    ) U_MIN_CNTL (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_min),
        .set_time  (change_min),
        .time_count(min),
        .o_tick    (w_tick_hour)
    );

    watch_time_counter #(
        .BIT_WIDTH(6),
        .TIMES(60),
        .TIME(0)
    ) U_SEC_CNTL (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_sec),
        .set_time  (change_sec),
        .time_count(sec),
        .o_tick    (w_tick_min)
    );

    watch_time_counter #(
        .BIT_WIDTH(7),
        .TIMES    (100),
        .TIME     (0)
    ) U_MSEC_CNTL (
        .clk(clk),
        .reset(reset),
        .i_tick(w_tick_100hz),
        .set_time(2'b00),
        .time_count(msec),
        .o_tick(w_tick_sec)
    );

endmodule
