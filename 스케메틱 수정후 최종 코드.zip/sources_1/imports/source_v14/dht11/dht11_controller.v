`timescale 1ns / 1ps

module dht11_controller (
    input             clk,
    input             reset,
    input             start,
    output     [15:0] humidity,
    output     [15:0] temperature,
    output reg        done,
    output reg        valid,
    inout             dht11_io
);

    localparam [2:0]
        IDLE  = 3'd0,
        START = 3'd1,
        WAIT  = 3'd2,
        SYNC  = 3'd3,
        DATA  = 3'd4,
        STOP  = 3'd5;

    localparam [1:0]
        SYNC_WAIT_LOW  = 2'd0,
        SYNC_MEAS_LOW  = 2'd1,
        SYNC_MEAS_HIGH = 2'd2;

    localparam [14:0] TIMEOUT_US = 15'd100;

    reg [2:0] c_state;
    reg [2:0] n_state;

    reg [14:0] tick_count_reg;
    reg [14:0] tick_count_next;

    reg [5:0] bit_count_reg;
    reg [5:0] bit_count_next;

    reg [39:0] data_reg;
    reg [39:0] data_next;

    reg io_control;

    reg dht11_io_reg;
    reg dht11_io_next;

    reg [1:0] sync_phase_reg;
    reg [1:0] sync_phase_next;

    reg wait_released_reg;
    reg wait_released_next;

    reg data_phase_reg;
    reg data_phase_next;

    reg dht_sync1;
    reg dht_sync2;

    wire dht11_in;
    wire tick_us;

    wire [7:0] checksum;
    wire [7:0] calc_checksum;

    assign dht11_io = io_control ? dht11_io_reg : 1'bz;
    assign dht11_in = dht_sync2;

    assign humidity = data_reg[39:24];
    assign temperature = data_reg[23:8];

    assign checksum = data_reg[7:0];

    assign calc_checksum =
        data_reg[39:32] +
        data_reg[31:24] +
        data_reg[23:16] +
        data_reg[15:8];

    tick_us U_TICK_US (
        .clk      (clk),
        .reset    (reset),
        .run_stop (1'b1),
        .clear    (1'b0),
        .o_tick_us(tick_us)
    );

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            dht_sync1 <= 1'b1;
            dht_sync2 <= 1'b1;
        end else begin
            dht_sync1 <= dht11_io;
            dht_sync2 <= dht_sync1;
        end
    end

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            c_state           <= IDLE;
            tick_count_reg    <= 15'd0;
            bit_count_reg     <= 6'd0;
            data_reg          <= 40'd0;
            dht11_io_reg      <= 1'b1;
            sync_phase_reg    <= SYNC_WAIT_LOW;
            data_phase_reg    <= 1'b0;
            wait_released_reg <= 1'b0;
        end else begin
            c_state           <= n_state;
            tick_count_reg    <= tick_count_next;
            bit_count_reg     <= bit_count_next;
            data_reg          <= data_next;
            dht11_io_reg      <= dht11_io_next;
            sync_phase_reg    <= sync_phase_next;
            data_phase_reg    <= data_phase_next;
            wait_released_reg <= wait_released_next;
        end
    end

    always @(*) begin
        n_state            = c_state;
        tick_count_next    = tick_count_reg;
        bit_count_next     = bit_count_reg;
        data_next          = data_reg;
        dht11_io_next      = dht11_io_reg;
        sync_phase_next    = sync_phase_reg;
        data_phase_next    = data_phase_reg;
        wait_released_next = wait_released_reg;

        io_control         = 1'b0;
        done               = 1'b0;
        valid              = 1'b0;

        case (c_state)
            IDLE: begin
                tick_count_next    = 15'd0;
                bit_count_next     = 6'd0;
                sync_phase_next    = SYNC_WAIT_LOW;
                data_phase_next    = 1'b0;
                wait_released_next = 1'b0;

                if (start) begin
                    n_state         = START;
                    tick_count_next = 15'd0;
                end
            end

            START: begin
                io_control    = 1'b1;
                dht11_io_next = 1'b0;

                if (tick_us) begin
                    if (tick_count_reg == 15'd18999) begin
                        tick_count_next    = 15'd0;
                        wait_released_next = 1'b0;
                        n_state            = WAIT;
                    end else begin
                        tick_count_next = tick_count_reg + 1'b1;
                    end
                end
            end

            WAIT: begin
                if (!wait_released_reg) begin
                    if (dht11_in) begin
                        wait_released_next = 1'b1;
                        tick_count_next    = 15'd0;
                    end else if (tick_us) begin
                        if (tick_count_reg >= TIMEOUT_US) begin
                            tick_count_next = 15'd0;
                            n_state         = IDLE;
                        end else begin
                            tick_count_next = tick_count_reg + 1'b1;
                        end
                    end
                end else begin
                    if (!dht11_in) begin
                        tick_count_next = 15'd0;
                        sync_phase_next = SYNC_WAIT_LOW;
                        n_state         = SYNC;
                    end else if (tick_us) begin
                        if (tick_count_reg >= TIMEOUT_US) begin
                            tick_count_next = 15'd0;
                            n_state         = IDLE;
                        end else begin
                            tick_count_next = tick_count_reg + 1'b1;
                        end
                    end
                end
            end

            SYNC: begin
                case (sync_phase_reg)
                    SYNC_WAIT_LOW: begin
                        tick_count_next = 15'd0;
                        sync_phase_next = SYNC_MEAS_LOW;
                    end

                    SYNC_MEAS_LOW: begin
                        if (dht11_in) begin
                            tick_count_next = 15'd0;
                            sync_phase_next = SYNC_MEAS_HIGH;
                        end else if (tick_us) begin
                            if (tick_count_reg >= TIMEOUT_US) begin
                                tick_count_next = 15'd0;
                                n_state         = IDLE;
                            end else begin
                                tick_count_next = tick_count_reg + 1'b1;
                            end
                        end
                    end

                    SYNC_MEAS_HIGH: begin
                        if (!dht11_in) begin
                            tick_count_next = 15'd0;
                            bit_count_next  = 6'd0;
                            data_phase_next = 1'b0;
                            n_state         = DATA;
                        end else if (tick_us) begin
                            if (tick_count_reg >= TIMEOUT_US) begin
                                tick_count_next = 15'd0;
                                n_state         = IDLE;
                            end else begin
                                tick_count_next = tick_count_reg + 1'b1;
                            end
                        end
                    end

                    default: begin
                        sync_phase_next = SYNC_WAIT_LOW;
                    end
                endcase
            end

            DATA: begin
                if (!data_phase_reg) begin
                    if (dht11_in) begin
                        tick_count_next = 15'd0;
                        data_phase_next = 1'b1;
                    end else if (tick_us) begin
                        if (tick_count_reg >= TIMEOUT_US) begin
                            tick_count_next = 15'd0;
                            n_state         = IDLE;
                        end else begin
                            tick_count_next = tick_count_reg + 1'b1;
                        end
                    end
                end else begin
                    if (dht11_in) begin
                        if (tick_us) begin
                            if (tick_count_reg >= TIMEOUT_US) begin
                                tick_count_next = 15'd0;
                                n_state         = IDLE;
                            end else begin
                                tick_count_next = tick_count_reg + 1'b1;
                            end
                        end
                    end else begin
                        if (tick_count_reg >= 15'd50)
                            data_next = {data_reg[38:0], 1'b1};
                        else data_next = {data_reg[38:0], 1'b0};

                        tick_count_next = 15'd0;
                        data_phase_next = 1'b0;

                        if (bit_count_reg == 6'd39) n_state = STOP;
                        else bit_count_next = bit_count_reg + 1'b1;
                    end
                end
            end

            STOP: begin
                done = 1'b1;

                if (checksum == calc_checksum) valid = 1'b1;
                else valid = 1'b0;

                n_state         = IDLE;
                tick_count_next = 15'd0;
            end

            default: begin
                n_state            = IDLE;
                tick_count_next    = 15'd0;
                bit_count_next     = 6'd0;
                data_next          = 40'd0;
                sync_phase_next    = SYNC_WAIT_LOW;
                data_phase_next    = 1'b0;
                wait_released_next = 1'b0;
            end
        endcase
    end

endmodule
