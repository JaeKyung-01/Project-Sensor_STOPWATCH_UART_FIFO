`timescale 1ns / 1ps

module tick_us (
    input  clk,
    input  reset,
    input  run_stop,
    input  clear,
    output o_tick_us
);

    parameter F_COUNT = 100;

    reg [$clog2(F_COUNT)-1:0] counter_reg;
    reg tick_us_reg;

    assign o_tick_us = tick_us_reg;

    always @(posedge clk or posedge reset) begin
        if (reset || clear) begin
            counter_reg <= 0;
            tick_us_reg <= 1'b0;
        end else if (run_stop) begin
            if (counter_reg == F_COUNT - 1) begin
                counter_reg <= 0;
                tick_us_reg <= 1'b1;
            end else begin
                counter_reg <= counter_reg + 1'b1;
                tick_us_reg <= 1'b0;
            end
        end else begin
            tick_us_reg <= 1'b0;
        end
    end

endmodule
