`timescale 1ns / 1ps

module sr04_control_unit (
    input        clk,
    input        reset,
    input  [3:0] i_ascii,
    input        i_start,
    output       o_start
);

    parameter IDLE = 1'b0, START = 1'b1;

    reg c_state, n_state;
    reg start_reg, start_next;

    assign o_start = start_reg;

    // State Register
    always @(posedge clk, posedge reset) begin
        if (reset) begin
            c_state   <= IDLE;
            start_reg <= 1'b0;
        end else begin
            c_state   <= n_state;
            start_reg <= start_next;
        end
    end

    // Next State & Output Logic
    always @(*) begin
        n_state    = c_state;
        start_next = 1'b0;

        case (c_state)
            IDLE: begin

                if (i_start || i_ascii[0]) begin
                    n_state = START;
                    start_next = 1'b1;
                end else begin
                    n_state = IDLE;
                end
            end

            START: begin
                start_next = 1'b0;
                n_state    = IDLE;
            end

        endcase
    end

endmodule
