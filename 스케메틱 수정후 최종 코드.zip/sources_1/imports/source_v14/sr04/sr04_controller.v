`timescale 1ns / 1ps

module sr04_controller (
    input            clk,
    input            reset,
    input            start,
    input            echo,
    output           done,
    output reg       trigger,
    output     [8:0] distance
);

    wire w_tick_us;

    localparam [2:0] IDLE = 0, START = 1, WAIT = 2, COUNT = 3, DISTANCE = 4;

    reg [2:0] c_state, n_state;
    reg run_stop;
    reg clear;
    reg [$clog2(58*400)-1:0] counter_reg, counter_next;
    reg [8:0] distance_reg;
    reg       done_reg;

    tick_us U_TICK_US (
        .clk      (clk),
        .reset    (reset),
        .run_stop (run_stop),
        .clear    (clear),
        .o_tick_us(w_tick_us)
    );

    assign distance = distance_reg;

    always @(posedge clk, posedge reset) begin
        if (reset) done_reg <= 1'b0;
        else       done_reg <= (c_state == DISTANCE);
    end
    assign done = done_reg;

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            c_state      <= IDLE;
            counter_reg  <= 0;
            distance_reg <= 0;
        end else begin
            c_state     <= n_state;
            counter_reg <= counter_next;

            if (c_state == DISTANCE) begin
                distance_reg <= counter_reg / 58;
            end
        end
    end

    always @(*) begin
        n_state      = c_state;
        counter_next = counter_reg;
        run_stop     = 1'b0;
        clear        = 1'b0;
        trigger      = 1'b0;

        case (c_state)
            IDLE: begin
                run_stop = 1'b0;
                clear    = 1'b1;
                trigger  = 1'b0;
                if (start) begin
                    n_state      = START;
                    counter_next = 0;
                end
            end

            START: begin
                run_stop = 1'b1;
                clear    = 1'b0;
                trigger  = 1'b1;
                if (w_tick_us) begin
                    counter_next = counter_reg + 1;
                end
                if (counter_reg == 11) begin
                    n_state = WAIT;
                    counter_next = 0;
                end
            end

            WAIT: begin
                run_stop = 1'b0;
                clear    = 1'b0;
                trigger  = 1'b0;

                if (echo) begin
                    clear = 1'b1;
                    counter_next = 0;
                    n_state = COUNT;
                end
            end

            COUNT: begin
                run_stop = 1'b1;
                clear    = 1'b0;
                trigger  = 1'b0;
                if (echo) begin
                    if (w_tick_us) begin
                        counter_next = counter_reg + 1;
                    end
                end else begin
                    n_state = DISTANCE;
                end
            end

            DISTANCE: begin
                run_stop = 1'b0;
                clear    = 1'b1;
                trigger  = 1'b0;
                n_state = IDLE;
            end

            default: begin
                n_state      = IDLE;
                counter_next = 0;
                run_stop     = 1'b0;
                clear        = 1'b1;
                trigger      = 1'b0;
            end
        endcase
    end

endmodule
