`timescale 1ns / 1ps

module main_control_unit (
    input clk,
    input reset,

    input [14:0] i_ascii,

    input btn_L,
    input btn_R,
    input btn_U,
    input btn_D,

    input [5:0] sw,

    output o_sw_run_stop,
    output o_sw_clear,
    output o_sw_mode,

    output [1:0] o_wt_change_sec,
    output [1:0] o_wt_change_min,
    output [1:0] o_wt_change_hour,
    output       o_wt_blink_sec,
    output       o_wt_blink_min,
    output       o_wt_blink_hour,

    output o_sr04_start,

    output       o_dht11_start,
    output [1:0] o_dht11_disp_sel,

    output o_stopwatch_split_save,
    output o_stopwatch_split_clear,

    output [1:0] o_active_src,
    output       o_disp_mode,

    output o_send_trig
);

    wire sw_watch = sw[0];
    wire sw_stopwatch = sw[1];
    wire sw_sr04 = sw[2];
    wire sw_dht11 = sw[3];
    wire sw_split = sw[4];
    wire sw_timemark = sw[5];

    assign o_active_src =
        sw_dht11     ? 2'b11 :
        sw_sr04      ? 2'b00 :
        sw_stopwatch ? 2'b01 :
                       2'b10;

    assign o_disp_mode = ~sw_timemark;

    wire       w_sw_run_stop = btn_L & sw_stopwatch;
    wire       w_sw_mode = btn_U & sw_stopwatch;
    wire       w_sw_clear = btn_R & sw_stopwatch & ~sw_split;

    wire [3:0] w_sw_ascii = sw_stopwatch ? i_ascii[3:0] : 4'b0000;

    stopwatch_control_unit U_STOPWATCH_CU (
        .clk       (clk),
        .reset     (reset),
        .i_ascii   (w_sw_ascii),
        .i_run_stop(w_sw_run_stop),
        .i_mode    (w_sw_mode),
        .i_clear   (w_sw_clear),
        .o_run_stop(o_sw_run_stop),
        .o_clear   (o_sw_clear),
        .o_mode    (o_sw_mode)
    );

    assign o_stopwatch_split_save  = btn_D & sw_stopwatch;

    assign o_stopwatch_split_clear = btn_R & sw_stopwatch & sw_split;

    wire [3:0] w_wt_ascii =
        sw_watch ?
        {i_ascii[13], i_ascii[14], i_ascii[11], i_ascii[12]} :
        4'b0000;

    watch_control_unit U_WATCH_CU (
        .clk          (clk),
        .reset        (reset),
        .i_ascii      (w_wt_ascii),
        .i_btn_L      (btn_L & sw_watch),
        .i_btn_R      (btn_R & sw_watch),
        .i_btn_U      (btn_U & sw_watch),
        .i_btn_D      (btn_D & sw_watch),
        .i_set_sw     (sw_watch),
        .o_change_sec (o_wt_change_sec),
        .o_change_min (o_wt_change_min),
        .o_change_hour(o_wt_change_hour),
        .o_blink_sec  (o_wt_blink_sec),
        .o_blink_min  (o_wt_blink_min),
        .o_blink_hour (o_wt_blink_hour)
    );

    wire [3:0] w_sr04_ascii = {3'b000, sw_sr04 & i_ascii[7]};

    sr04_control_unit U_SR04_CU (
        .clk    (clk),
        .reset  (reset),
        .i_ascii(w_sr04_ascii),
        .i_start(btn_R & sw_sr04),
        .o_start(o_sr04_start)
    );

    wire w_dht11_ascii_start = sw_dht11 & i_ascii[9];

    dht11_control_unit U_DHT11_CU (
        .clk    (clk),
        .reset  (reset),
        .i_start((btn_R & sw_dht11) | w_dht11_ascii_start),
        .o_start(o_dht11_start)
    );

    reg [1:0] dht11_disp_sel_reg;

    always @(posedge clk, posedge reset) begin
        if (reset) dht11_disp_sel_reg <= 2'b00;
        else if (sw_dht11 & (btn_L | i_ascii[10])) dht11_disp_sel_reg <= 2'b00;
        else if (sw_dht11 & (btn_U | i_ascii[6])) dht11_disp_sel_reg <= 2'b01;
        else if (sw_dht11 & (btn_D | i_ascii[8])) dht11_disp_sel_reg <= 2'b10;
    end

    assign o_dht11_disp_sel = dht11_disp_sel_reg;

    reg btn_L_d;
    reg btn_R_d;
    reg btn_U_d;
    reg btn_D_d;

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            btn_L_d <= 1'b0;
            btn_R_d <= 1'b0;
            btn_U_d <= 1'b0;
            btn_D_d <= 1'b0;
        end else begin
            btn_L_d <= btn_L;
            btn_R_d <= btn_R;
            btn_U_d <= btn_U;
            btn_D_d <= btn_D;
        end
    end

    wire w_edge_L = btn_L & ~btn_L_d;
    wire w_edge_R = btn_R & ~btn_R_d;
    wire w_edge_U = btn_U & ~btn_U_d;
    wire w_edge_D = btn_D & ~btn_D_d;

    wire w_any_mode_active = sw_watch | sw_stopwatch | sw_sr04 | sw_dht11;

    assign o_send_trig =
        w_any_mode_active &
        (w_edge_L | w_edge_R | w_edge_U | w_edge_D);

endmodule
