`timescale 1ns / 1ps

module project_sensor_stopwatch_uart_fifo (
    input       clk,
    input       reset,
    input       btn_L,
    input       btn_R,
    input       btn_U,
    input       btn_D,
    input [5:0] sw,
    input       sr04_echo,
    inout       dht11_io,
    input       rx,

    output       tx,
    output       sr04_trigger,
    output [7:0] fnd_data,
    output [3:0] fnd_com,
    output [5:0] led
);

    // =========================================================
    // Button Debounce
    // =========================================================

    wire w_btn_L;
    wire w_btn_R;
    wire w_btn_U;
    wire w_btn_D;

    btn_debounce U_DEB_L (
        .clk  (clk),
        .reset(reset),
        .i_btn(btn_L),
        .o_btn(w_btn_L)
    );

    btn_debounce U_DEB_R (
        .clk  (clk),
        .reset(reset),
        .i_btn(btn_R),
        .o_btn(w_btn_R)
    );

    btn_debounce U_DEB_U (
        .clk  (clk),
        .reset(reset),
        .i_btn(btn_U),
        .o_btn(w_btn_U)
    );

    btn_debounce U_DEB_D (
        .clk  (clk),
        .reset(reset),
        .i_btn(btn_D),
        .o_btn(w_btn_D)
    );

    // =========================================================
    // UART FIFO
    // =========================================================

    wire [7:0] w_rx_rdata;
    wire       w_rx_empty;
    wire       w_rx_pop;

    wire [7:0] w_tx_wdata;
    wire       w_tx_push;
    wire       w_tx_full;

    uart_fifo U_UART_FIFO (
        .clk  (clk),
        .reset(reset),
        .rx   (rx),
        .tx   (tx),

        .rx_rdata(w_rx_rdata),
        .rx_empty(w_rx_empty),
        .rx_pop  (w_rx_pop),

        .tx_wdata(w_tx_wdata),
        .tx_push (w_tx_push),
        .tx_full (w_tx_full)
    );

    // =========================================================
    // ASCII Decoder
    // =========================================================

    wire [14:0] w_ascii;

    ascii_decoder U_ASCII_DECODER (
        .rdata  (w_rx_rdata),
        .empty  (w_rx_empty),
        .pop    (w_rx_pop),
        .o_ascii(w_ascii)
    );

    // =========================================================
    // Main Control Unit
    // =========================================================

    wire       w_sw_run_stop;
    wire       w_sw_clear;
    wire       w_sw_mode;

    wire [1:0] w_wt_change_sec;
    wire [1:0] w_wt_change_min;
    wire [1:0] w_wt_change_hour;

    wire       w_wt_blink_sec;
    wire       w_wt_blink_min;
    wire       w_wt_blink_hour;

    wire       w_sr04_start;

    wire       w_dht11_start;
    wire [1:0] w_dht11_disp_sel;

    wire       w_stopwatch_split_save;
    wire       w_stopwatch_split_clear;

    wire [1:0] w_active_src;
    wire       w_disp_mode;

    wire       w_ctrl_send_trig;

    (* keep_hierarchy = "yes" *)
    main_control_unit U_MAIN_CONTROL_UNIT (
        .clk    (clk),
        .reset  (reset),
        .i_ascii(w_ascii),

        .btn_L(w_btn_L),
        .btn_R(w_btn_R),
        .btn_U(w_btn_U),
        .btn_D(w_btn_D),

        .sw(sw),

        .o_sw_run_stop(w_sw_run_stop),
        .o_sw_clear   (w_sw_clear),
        .o_sw_mode    (w_sw_mode),

        .o_wt_change_sec (w_wt_change_sec),
        .o_wt_change_min (w_wt_change_min),
        .o_wt_change_hour(w_wt_change_hour),

        .o_wt_blink_sec (w_wt_blink_sec),
        .o_wt_blink_min (w_wt_blink_min),
        .o_wt_blink_hour(w_wt_blink_hour),

        .o_sr04_start(w_sr04_start),

        .o_dht11_start   (w_dht11_start),
        .o_dht11_disp_sel(w_dht11_disp_sel),

        .o_stopwatch_split_save (w_stopwatch_split_save),
        .o_stopwatch_split_clear(w_stopwatch_split_clear),

        .o_active_src(w_active_src),
        .o_disp_mode (w_disp_mode),

        .o_send_trig(w_ctrl_send_trig)
    );

    // =========================================================
    // Stopwatch Datapath
    // =========================================================

    wire [6:0] w_sw_msec;
    wire [5:0] w_sw_sec;
    wire [5:0] w_sw_min;
    wire [4:0] w_sw_hour;

    wire [6:0] w_split_msec;
    wire [5:0] w_split_sec;
    wire [5:0] w_split_min;
    wire [4:0] w_split_hour;

    (* keep_hierarchy = "yes" *)
    stopwatch_datapath U_STOPWATCH_DP (
        .clk  (clk),
        .reset(reset),

        .run_stop(w_sw_run_stop),
        .clear   (w_sw_clear),
        .mode    (w_sw_mode),

        .split_save (w_stopwatch_split_save),
        .split_clear(w_stopwatch_split_clear),

        .msec(w_sw_msec),
        .sec (w_sw_sec),
        .min (w_sw_min),
        .hour(w_sw_hour),

        .split_msec(w_split_msec),
        .split_sec (w_split_sec),
        .split_min (w_split_min),
        .split_hour(w_split_hour)
    );

    // =========================================================
    // Watch Datapath
    // =========================================================

    wire [6:0] w_wt_msec;
    wire [5:0] w_wt_sec;
    wire [5:0] w_wt_min;
    wire [4:0] w_wt_hour;

    (* keep_hierarchy = "yes" *)
    watch_datapath U_WATCH_DP (
        .clk  (clk),
        .reset(reset),

        .change_sec (w_wt_change_sec),
        .change_min (w_wt_change_min),
        .change_hour(w_wt_change_hour),

        .msec(w_wt_msec),
        .sec (w_wt_sec),
        .min (w_wt_min),
        .hour(w_wt_hour)
    );

    // =========================================================
    // SR04 Controller
    // =========================================================

    wire [8:0] w_sr04_distance;
    wire       w_sr04_done;

    (* keep_hierarchy = "yes" *)
    sr04_controller U_SR04_CTRL (
        .clk  (clk),
        .reset(reset),

        .start(w_sr04_start),
        .echo (sr04_echo),

        .done    (w_sr04_done),
        .trigger (sr04_trigger),
        .distance(w_sr04_distance)
    );

    // =========================================================
    // DHT11
    // =========================================================

    wire [15:0] w_dht11_humidity;
    wire [15:0] w_dht11_temperature;

    wire [7:0] w_dht11_fahr_val;

    wire w_dht11_done;
    wire w_dht11_valid;

    (* keep_hierarchy = "yes" *)
    dht11 U_DHT11 (
        .clk  (clk),
        .reset(reset),

        .start(w_dht11_start),

        .humidity   (w_dht11_humidity),
        .temperature(w_dht11_temperature),
        .fahrenheit (w_dht11_fahr_val),

        .done (w_dht11_done),
        .valid(w_dht11_valid),

        .dht11_io(dht11_io)
    );

    // =========================================================
    // DHT11 Data
    // =========================================================

    wire [7:0] w_dht11_temp_val;
    wire [7:0] w_dht11_humid_val;

    assign w_dht11_temp_val  = w_dht11_temperature[15:8];

    assign w_dht11_humid_val = w_dht11_humidity[15:8];

    // =========================================================
    // Display MUX
    // =========================================================

    wire [6:0] w_fnd_msec;
    wire [7:0] w_fnd_sec;
    wire [7:0] w_fnd_min;
    wire [4:0] w_fnd_hour;

    wire w_disp_mode_final;

    (* keep_hierarchy = "yes" *)
    display_mux U_DISPLAY_MUX (
        .active_src(w_active_src),
        .disp_mode (w_disp_mode),
        .split_mode(sw[4]),

        .sw_msec(w_sw_msec),
        .sw_sec (w_sw_sec),
        .sw_min (w_sw_min),
        .sw_hour(w_sw_hour),

        .split_msec(w_split_msec),
        .split_sec (w_split_sec),
        .split_min (w_split_min),
        .split_hour(w_split_hour),

        .wt_msec(w_wt_msec),
        .wt_sec (w_wt_sec),
        .wt_min (w_wt_min),
        .wt_hour(w_wt_hour),

        .sr04_distance(w_sr04_distance),

        .dht11_temp_val (w_dht11_temp_val),
        .dht11_humid_val(w_dht11_humid_val),
        .dht11_fahr_val (w_dht11_fahr_val),
        .dht11_disp_sel (w_dht11_disp_sel),

        .fnd_msec(w_fnd_msec),
        .fnd_sec (w_fnd_sec),
        .fnd_min (w_fnd_min),
        .fnd_hour(w_fnd_hour),

        .disp_mode_final(w_disp_mode_final)
    );

    // =========================================================
    // FND Controller
    // =========================================================

    (* keep_hierarchy = "yes" *)
    fnd_controller #(
        .SEC_WIDTH(8),
        .MIN_WIDTH(8)
    ) U_FND_CONTROLLER (
        .clk  (clk),
        .reset(reset),

        .msec(w_fnd_msec),
        .sec (w_fnd_sec),
        .min (w_fnd_min),
        .hour(w_fnd_hour),

        .display_mode(w_disp_mode_final),

        .active_src(w_active_src),

        .blink_sec (w_wt_blink_sec),
        .blink_min (w_wt_blink_min),
        .blink_hour(w_wt_blink_hour),

        .fnd_com (fnd_com),
        .fnd_data(fnd_data)
    );

    // =========================================================
    // UART Send Data
    // =========================================================

    wire [6:0] w_send_msec;
    wire [5:0] w_send_sec;
    wire [5:0] w_send_min;
    wire [4:0] w_send_hour;

    assign w_send_msec = w_fnd_msec;
    assign w_send_sec  = w_fnd_sec[5:0];
    assign w_send_min  = w_fnd_min[5:0];
    assign w_send_hour = w_fnd_hour;

    // =========================================================
    // ASCII Sender
    // =========================================================

    ascii_sender U_ASCII_SENDER (
        .clk  (clk),
        .reset(reset),

        .src_sel(w_active_src),

        .ctrl_send_trig(w_ctrl_send_trig),
        .sr04_done     (w_sr04_done),
        .dht11_done    (w_dht11_done),
        .dht11_valid   (w_dht11_valid),

        .sr04_distance(w_sr04_distance),

        .time_msec(w_send_msec),
        .time_sec (w_send_sec),
        .time_min (w_send_min),
        .time_hour(w_send_hour),

        .dht11_temp (w_dht11_temp_val),
        .dht11_humid(w_dht11_humid_val),
        .dht11_fahr (w_dht11_fahr_val),

        .tx_data(w_tx_wdata),
        .push   (w_tx_push),
        .full   (w_tx_full),

        .busy     (),
        .send_done()
    );

    // =========================================================
    // LED
    // =========================================================

    assign led = 6'b111111;

endmodule
