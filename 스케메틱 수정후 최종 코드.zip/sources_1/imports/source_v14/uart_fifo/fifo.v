`timescale 1ns / 1ps

module fifo #(
    parameter WIDTH = 2
) (
    input        clk,
    input        reset,
    input        push,
    input        pop,
    input  [7:0] wdata,
    output [7:0] rdata,
    output       full,
    output       empty
);

    wire [WIDTH-1:0] w_wptr, w_rptr;

    register_file #(
        .WIDTH(WIDTH)
    ) U_REG_FILE (
        .clk  (clk),
        .waddr(w_wptr),
        .raddr(w_rptr),
        .wdata(wdata),
        .we   ((~full & push)),
        .rdata(rdata)

    );

    control_unit #(
        .WIDTH(WIDTH)
    ) U_CONTROL_UNIT (
        .clk  (clk),
        .reset(reset),
        .push (push),
        .pop  (pop),
        .wptr (w_wptr),
        .rptr (w_rptr),
        .full (full),
        .empty(empty)
    );

endmodule