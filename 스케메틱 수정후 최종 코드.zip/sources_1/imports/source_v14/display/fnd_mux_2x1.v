`timescale 1ns / 1ps

module fnd_mux_2x1 (
    input            sel,
    input      [3:0] in0,
    input      [3:0] in1,
    output reg [3:0] mux_out
);
    always @(*) begin
        if (sel == 1) begin
            mux_out = in1;
        end else begin
            mux_out = in0;
        end
    end
endmodule
