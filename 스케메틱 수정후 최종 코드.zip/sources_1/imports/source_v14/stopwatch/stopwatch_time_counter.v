`timescale 1ns / 1ps

module stopwatch_time_counter #(
    parameter BIT_WIDTH = 7,
    TIMES = 100
) (
    input clk,
    input reset,
    input i_tick,
    input mode,
    input run_stop,
    input clear,
    output reg [BIT_WIDTH -1:0] time_count,
    output reg o_tick

);

    always @(posedge clk, posedge reset) begin
        if (reset | clear) begin
            time_count <= 0;
            o_tick <= 1'b0;
        end else begin
            o_tick <= 0;
            if (run_stop & i_tick) begin
                if (!mode) begin
                    time_count <= time_count + 1;
                    if (time_count == (TIMES - 1)) begin
                        time_count <= 0;
                        o_tick <= 1'b1;
                    end else o_tick <= 1'b0;
                end else begin
                    time_count <= time_count - 1;
                    if (time_count == 0) begin
                        time_count <= TIMES - 1;
                        o_tick <= 1'b1;

                    end
                end
            end
        end
    end

endmodule