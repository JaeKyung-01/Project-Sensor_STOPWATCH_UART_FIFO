`timescale 1ns / 1ps

module stopwatch_datapath #(
    parameter MSEC_WIDTH = 7,
    SEC_WIDTH = 6,
    MIN_WIDTH = 6,
    HOUR_WIDTH = 5
) (
    input clk,
    input reset,
    input run_stop,
    input clear,
    input mode,

    input split_save,
    input split_clear,

    output reg [MSEC_WIDTH-1:0] msec,
    output reg [ SEC_WIDTH-1:0] sec,
    output reg [ MIN_WIDTH-1:0] min,
    output reg [HOUR_WIDTH-1:0] hour,

    output reg [MSEC_WIDTH-1:0] split_msec,
    output reg [ SEC_WIDTH-1:0] split_sec,
    output reg [ MIN_WIDTH-1:0] split_min,
    output reg [HOUR_WIDTH-1:0] split_hour
);

    // =========================================================
    // Stopwatch Counter
    // =========================================================

    wire w_tick_100hz;
    wire w_tick_sec;
    wire w_tick_min;
    wire w_tick_hour;

    wire [MSEC_WIDTH-1:0] w_msec;
    wire [SEC_WIDTH-1:0] w_sec;
    wire [MIN_WIDTH-1:0] w_min;
    wire [HOUR_WIDTH-1:0] w_hour;

    tick_gen_100hz U_TICK_GEN (
        .clk   (clk),
        .reset (reset),
        .o_tick(w_tick_100hz)
    );

    stopwatch_time_counter #(
        .BIT_WIDTH(MSEC_WIDTH),
        .TIMES(100)
    ) MSEC_COUNTER (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_100hz),
        .mode      (mode),
        .run_stop  (run_stop),
        .clear     (clear),
        .time_count(w_msec),
        .o_tick    (w_tick_sec)
    );

    stopwatch_time_counter #(
        .BIT_WIDTH(SEC_WIDTH),
        .TIMES(60)
    ) SEC_COUNTER (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_sec),
        .mode      (mode),
        .run_stop  (run_stop),
        .clear     (clear),
        .time_count(w_sec),
        .o_tick    (w_tick_min)
    );

    stopwatch_time_counter #(
        .BIT_WIDTH(MIN_WIDTH),
        .TIMES(60)
    ) MIN_COUNTER (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_min),
        .mode      (mode),
        .run_stop  (run_stop),
        .clear     (clear),
        .time_count(w_min),
        .o_tick    (w_tick_hour)
    );

    stopwatch_time_counter #(
        .BIT_WIDTH(HOUR_WIDTH),
        .TIMES(24)
    ) HOUR_COUNTER (
        .clk       (clk),
        .reset     (reset),
        .i_tick    (w_tick_hour),
        .mode      (mode),
        .run_stop  (run_stop),
        .clear     (clear),
        .time_count(w_hour),
        .o_tick    ()
    );

    // =========================================================
    // Stopwatch Output Register
    // =========================================================

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            msec <= 0;
            sec  <= 0;
            min  <= 0;
            hour <= 0;
        end else begin
            msec <= w_msec;
            sec  <= w_sec;
            min  <= w_min;
            hour <= w_hour;
        end
    end

    // =========================================================
    // Split Save Edge Detect
    // =========================================================

    reg split_save_d;

    always @(posedge clk, posedge reset) begin
        if (reset) split_save_d <= 1'b0;
        else split_save_d <= split_save;
    end

    wire split_save_edge;

    assign split_save_edge = split_save & ~split_save_d;

    // =========================================================
    // Split Data Register
    // =========================================================

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            split_msec <= 0;
            split_sec  <= 0;
            split_min  <= 0;
            split_hour <= 0;
        end else if (split_clear) begin
            split_msec <= 0;
            split_sec  <= 0;
            split_min  <= 0;
            split_hour <= 0;
        end else if (split_save_edge) begin
            split_msec <= msec;
            split_sec  <= sec;
            split_min  <= min;
            split_hour <= hour;
        end
    end

endmodule
