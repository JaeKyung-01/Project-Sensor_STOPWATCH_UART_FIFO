`timescale 1ns / 1ps

module stopwatch_control_unit (
    input        clk,
    input        reset,
    input  [3:0] i_ascii,
    input        i_run_stop,
    input        i_mode,
    input        i_clear,
    output       o_run_stop,
    output       o_clear,
    output       o_mode
);

    parameter STOP = 0, RUN = 1, CLEAR = 2, MODE = 3;

    reg [1:0] c_state, n_state;

    reg run_stop_reg, run_stop_next;
    reg clear_reg, clear_next;
    reg mode_reg, mode_next;

    assign o_run_stop = run_stop_reg;
    assign o_clear    = clear_reg;
    assign o_mode     = mode_reg;

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            c_state      <= STOP;
            run_stop_reg <= 1'b0;
            clear_reg    <= 1'b0;
            mode_reg     <= 1'b0;
        end else begin
            c_state      <= n_state;
            run_stop_reg <= run_stop_next;
            clear_reg    <= clear_next;
            mode_reg     <= mode_next;
        end
    end

    always @(*) begin
        n_state       = c_state;
        run_stop_next = run_stop_reg;
        clear_next    = clear_reg;
        mode_next     = mode_reg;

        case (c_state)
            STOP: begin
                run_stop_next = 1'b0;
                clear_next    = 1'b0;

                if (i_run_stop || i_ascii[0]) n_state = RUN;
                else if (i_clear || i_ascii[2]) n_state = CLEAR;
                else if (i_mode || i_ascii[3]) n_state = MODE;
            end

            MODE: begin
                mode_next = ~mode_next;
                n_state   = STOP;
            end

            CLEAR: begin
                clear_next = 1'b1;
                n_state    = STOP;
            end

            RUN: begin
                run_stop_next = 1'b1;

                if (i_run_stop || i_ascii[1]) n_state = STOP;
            end

            default: begin
                n_state = STOP;
            end
        endcase
    end

endmodule
